gaussian-elimination
====================

Javascript implementation of Gaussian elimination algorithm for solving systems of linear equations.
