Copy and paste the "eccentric_circle.m" file to MATLAB.
Then run the file .